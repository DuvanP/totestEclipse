module jdbc_review {
	requires java.sql;
}